#!/usr/bin/env python3
"""Python Developer Kit -- Launcher"""

import os, sys, time, subprocess
from pathlib import Path


def _ensure(pkg, mod=None):
    import importlib
    try:
        importlib.import_module(mod or pkg)
    except ModuleNotFoundError:
        print(f"  Installing {pkg}...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", pkg, "-q"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

_ensure("rich")
_ensure("colorama")

from rich.console import Console
from rich.panel   import Panel
from rich.table   import Table
from rich.text    import Text
from rich.rule    import Rule
from rich.align   import Align
from rich         import box
import colorama
colorama.init()

console = Console()

BANNER = (
    "\n"
    "  ____             _  ___ _\n"
    " |  _ \\  _____   _| |/ (_) |_\n"
    " | | | |/ _ \\ \\ / / ' /| | __|\n"
    " | |_| |  __/\\ V /| . \\| | |_\n"
    " |____/ \\___| \\_/ |_|\\_\\_|\\__|\n"
)

BASE = Path(__file__).parent.parent

PROJECTS = [
    {
        "key": "1",
        "title": "Lead Enricher",
        "icon": "[L]",
        "desc": "Validate emails, detect company, query Hunter.io & Clearbit. Export CSV+Excel.",
        "color": "yellow",
        "folder": "lead_enricher_3",
        "script": "lead_enricher.py",
        "args": ["sample_leads.csv"],
        "deps": ["pandas", "requests", "openpyxl"],
        "note": "Optional: add --hunter-key YOUR_KEY for Hunter.io enrichment.",
    },
    {
        "key": "2",
        "title": "Gmail Campaign Sender",
        "icon": "[M]",
        "desc": "Send personalised HTML campaigns from a CSV contact list via Gmail API OAuth2.",
        "color": "cyan",
        "folder": "gmail-campaign-sender6",
        "script": "gmail_campaign.py",
        "args": ["--help"],
        "deps": ["google-auth", "google-auth-oauthlib", "google-api-python-client"],
        "note": "Needs credentials.json from Google Cloud Console.",
    },
    {
        "key": "3",
        "title": "GitHub Dashboard",
        "icon": "[G]",
        "desc": "Flask web dashboard for GitHub repos -- issues, PRs, contributors, metrics.",
        "color": "white",
        "folder": "github_dashboard_app8",
        "script": "app.py",
        "args": [],
        "deps": ["flask", "requests", "python-dotenv"],
        "note": "Needs GITHUB_TOKEN in .env. Opens on http://localhost:5000",
    },
    {
        "key": "4",
        "title": "Google Sheets Lead Sync",
        "icon": "[S]",
        "desc": "Sync a local CSV of leads to a Google Sheet -- inserts, updates, dedupes.",
        "color": "green",
        "folder": "google-sheets-leads-sync2",
        "script": "sync_leads.py",
        "args": ["--help"],
        "deps": ["gspread", "google-auth"],
        "note": "Needs service_account.json and --spreadsheet-id argument.",
    },
    {
        "key": "5",
        "title": "Support Ticket System",
        "icon": "[T]",
        "desc": "Flask web app to create, manage and export support tickets with SQLite.",
        "color": "magenta",
        "folder": "support_tickets4",
        "script": "app.py",
        "args": [],
        "deps": ["flask", "pandas", "openpyxl"],
        "note": "Opens on http://localhost:5000 -- press Ctrl+C to stop.",
    },
    {
        "key": "6",
        "title": "Telegram Business Bot",
        "icon": "[B]",
        "desc": "Telegram bot that sends alerts, monitors thresholds, scheduled notifications.",
        "color": "blue",
        "folder": "telegram_business_alerts_bot7",
        "script": "bot.py",
        "args": [],
        "deps": ["python-telegram-bot", "schedule", "python-dotenv"],
        "note": "Needs TELEGRAM_TOKEN in .env. Press Ctrl+C to stop.",
    },
    {
        "key": "7",
        "title": "Webhook Server",
        "icon": "[W]",
        "desc": "FastAPI server for Stripe, GitHub and form webhooks. SQLite + Telegram alerts.",
        "color": "red",
        "folder": "webhook_server5",
        "script": "main.py",
        "args": [],
        "deps": ["fastapi", "uvicorn", "python-dotenv", "gspread"],
        "note": "Needs .env with STRIPE_SECRET, GITHUB_SECRET, TELEGRAM_TOKEN. Port 8000.",
    },
    {
        "key": "8",
        "title": "Crypto Portfolio Tracker",
        "icon": "[C]",
        "desc": "Track crypto holdings with live CoinGecko prices. P&L, alerts, export history.",
        "color": "yellow",
        "folder": "",
        "script": "crypto_portfolio.py",
        "args": ["show"],
        "deps": ["requests", "rich"],
        "note": "python crypto_portfolio.py add BTC 0.5 | show | export | alert BTC 100000",
    },
    {
        "key": "9",
        "title": "System Monitor",
        "icon": "[*]",
        "desc": "Real-time terminal dashboard: CPU, RAM, disk and network stats.",
        "color": "cyan",
        "folder": "",
        "script": "system_monitor.py",
        "args": [],
        "deps": ["psutil", "rich"],
        "note": "Press Ctrl+C to exit the live dashboard.",
    },
    {
        "key": "10",
        "title": "DataSync",
        "icon": "[D]",
        "desc": "Sync and deduplicate CSV/JSON data pipelines with progress bars and diff report.",
        "color": "bright_cyan",
        "folder": "",
        "script": "datasync.py",
        "args": ["--help"],
        "deps": ["rich", "click"],
        "note": "Run --help to see full usage options.",
    },
]


# ---------------------------------------------------------------------------
# Animations
# ---------------------------------------------------------------------------

def animated_banner():
    colors = [
        "bold red", "bold yellow", "bold green",
        "bold cyan", "bold blue", "bold magenta", "bold cyan",
    ]
    for color in colors:
        console.clear()
        console.print(BANNER, style=color, justify="center")
        time.sleep(0.07)


def loading_bar(label: str, duration: float = 1.2):
    width = 38
    steps = 32
    console.print()
    for i in range(steps + 1):
        filled = int(width * i / steps)
        bar    = "#" * filled + "." * (width - filled)
        pct    = int(100 * i / steps)
        console.print(
            f"  [bold cyan]{label}[/]  [cyan][{bar}][/]  [bold white]{pct}%[/]",
            end="\r",
        )
        time.sleep(duration / steps)
    console.print()


# ---------------------------------------------------------------------------
# Menu & details
# ---------------------------------------------------------------------------

def render_menu():
    console.clear()
    console.print(BANNER, style="bold cyan", justify="center")
    console.print(
        Panel(
            Align.center(Text("** Python Developer Kit -- Project Launcher **", style="bold white")),
            border_style="cyan",
            padding=(0, 2),
        )
    )
    console.print()

    table = Table(
        box=box.ASCII2,
        border_style="cyan",
        header_style="bold cyan",
        show_header=True,
        show_lines=False,
        padding=(0, 2),
        expand=False,
    )
    table.add_column("#",           style="bold yellow", width=4,  justify="center")
    table.add_column(" ",           style="white",       width=5)
    table.add_column("Project",     style="bold white",  width=28)
    table.add_column("Key deps",    style="dim cyan",    width=28)
    table.add_column("Description", style="dim white",   min_width=40)

    for p in PROJECTS:
        c    = p["color"]
        tags = "  ".join(p["deps"][:3])
        table.add_row(
            p["key"],
            p["icon"],
            f"[bold {c}]{p['title']}[/]",
            f"[dim]{tags}[/]",
            p["desc"],
        )

    console.print(table)
    console.print()
    console.print(
        Panel(
            "[dim white]Type a number to launch  [bold cyan]1-10[/]"
            "   |   [bold cyan]d<N>[/][dim white] for details e.g. [bold cyan]d4[/]"
            "   |   [bold cyan]q[/][dim white] to quit[/]",
            border_style="dim cyan",
            padding=(0, 2),
        )
    )
    console.print()


def show_detail(project: dict):
    c = project["color"]
    content = Text()
    content.append(f"{project['icon']}  {project['title']}\n\n", style=f"bold {c}")
    content.append(project["desc"] + "\n", style="white")
    content.append("\n  Deps:      ", style="dim")
    content.append(", ".join(project["deps"]), style="yellow")
    content.append("\n\n  Note:      ", style="dim")
    content.append(project["note"], style="italic dim white")
    folder = BASE / project["folder"] if project["folder"] else BASE
    content.append("\n\n  Directory: ", style="dim")
    content.append(str(folder), style="dim cyan")
    content.append("\n\n  Command:   ", style="dim")
    cmd = f"python {project['script']} {' '.join(project['args'])}".strip()
    content.append(cmd, style="bright_cyan")
    console.print()
    console.print(
        Panel(
            content,
            title=f"[bold cyan]Script #{project['key']} -- Details[/]",
            border_style=c,
            padding=(1, 3),
        )
    )
    console.print()


# ---------------------------------------------------------------------------
# Dependency auto-install
# ---------------------------------------------------------------------------

MOD_MAP = {
    "google-auth":              "google.auth",
    "google-auth-oauthlib":     "google_auth_oauthlib",
    "google-api-python-client": "googleapiclient",
    "python-telegram-bot":      "telegram",
    "python-dotenv":            "dotenv",
}


def install_deps(deps: list) -> bool:
    missing = []
    for dep in deps:
        mod = MOD_MAP.get(dep, dep.replace("-", "_"))
        try:
            __import__(mod)
        except ImportError:
            missing.append(dep)

    if not missing:
        console.print("  [bold green][OK][/]  All dependencies already installed.")
        return True

    console.print(f"  [bold yellow][!][/]  Installing: [yellow]{', '.join(missing)}[/]")
    with console.status("[cyan]Running pip install...[/]", spinner="dots"):
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install"] + missing + ["-q"],
            capture_output=True, text=True,
        )
    if r.returncode == 0:
        console.print("  [bold green][OK][/]  Packages installed successfully.")
        return True
    console.print(f"  [bold red][X][/]  pip install failed:\n{r.stderr[:400]}")
    return False


# ---------------------------------------------------------------------------
# Launch
# ---------------------------------------------------------------------------

def launch(project: dict):
    console.clear()
    c     = project["color"]
    title = project["title"]
    icon  = project["icon"]

    console.print()
    console.print(
        Panel(
            Align.center(Text(f"{icon}  {title}", style=f"bold {c}")),
            border_style=c,
            padding=(1, 4),
        )
    )
    console.print()

    console.print("  [dim]Checking dependencies...[/]")
    if not install_deps(project["deps"]):
        input("\n  Press Enter to go back...")
        return

    console.print()
    loading_bar(f"Launching  {icon}  {title}", duration=0.9)

    script_path = (
        BASE / project["folder"] / project["script"]
        if project["folder"] else BASE / project["script"]
    )
    work_dir = BASE / project["folder"] if project["folder"] else BASE

    if not script_path.exists():
        console.print(f"  [bold red][X][/]  Script not found: {script_path}")
        input("\n  Press Enter to go back...")
        return

    console.print(
        f"  [dim]cmd:[/dim] [bold cyan]{project['script']}[/]"
        f" [dim]{' '.join(project['args'])}[/dim]"
    )
    console.print()
    console.print(Rule(f"[dim]-- {title} output --[/]", style="dim cyan"))
    console.print()

    try:
        subprocess.run([sys.executable, str(script_path)] + project["args"], cwd=str(work_dir))
    except KeyboardInterrupt:
        console.print("\n  [bold yellow]Script interrupted.[/]")

    console.print()
    console.print(Rule("[dim]-- end of output --[/]", style="dim cyan"))
    console.print(f"\n  [bold green][OK]  {title}  finished.[/]\n")
    input("  Press Enter to return to menu...")


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def main():
    animated_banner()
    loading_bar("Loading Python Developer Kit", duration=1.1)

    key_map = {p["key"]: p for p in PROJECTS}

    while True:
        render_menu()
        try:
            choice = input("  > ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            break

        if choice in ("q", "quit", "exit"):
            break

        if choice in ("r", "refresh", ""):
            continue

        if choice.startswith("d"):
            rest = choice[1:].strip()
            if rest in key_map:
                console.clear()
                show_detail(key_map[rest])
                input("  Press Enter to return to menu...")
            else:
                console.print(f"  [bold red][X]  Unknown script number:[/] {rest!r}")
                time.sleep(0.8)
            continue

        if choice in key_map:
            launch(key_map[choice])
            continue

        console.print(f"  [bold red]Unknown option:[/] {choice!r}")
        time.sleep(0.7)

    console.print()
    console.print(
        Panel(
            Align.center(Text("See you later!", style="bold cyan")),
            border_style="cyan",
            padding=(1, 6),
        )
    )
    time.sleep(0.6)


if __name__ == "__main__":
    main()
