import sqlite3
import os
import io
from datetime import datetime, timezone
from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, send_file, g
)
import pandas as pd

app = Flask(__name__)
app.secret_key = "change-me-in-production"

DATABASE = os.path.join(os.path.dirname(__file__), "tickets.db")

STATUSES = ["open", "in-progress", "closed"]
PRIORITIES = ["low", "medium", "high", "critical"]

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.executescript("""
        CREATE TABLE IF NOT EXISTS agents (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            name      TEXT    NOT NULL UNIQUE,
            email     TEXT    NOT NULL UNIQUE,
            created_at TEXT   NOT NULL
        );

        CREATE TABLE IF NOT EXISTS tickets (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            title        TEXT    NOT NULL,
            description  TEXT    NOT NULL,
            status       TEXT    NOT NULL DEFAULT 'open',
            priority     TEXT    NOT NULL DEFAULT 'medium',
            agent_id     INTEGER REFERENCES agents(id),
            created_at   TEXT    NOT NULL,
            updated_at   TEXT    NOT NULL,
            closed_at    TEXT
        );
    """)
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Routes — Dashboard
# ---------------------------------------------------------------------------

@app.route("/")
def dashboard():
    db = get_db()

    counts = {row["status"]: row["total"] for row in db.execute(
        "SELECT status, COUNT(*) as total FROM tickets GROUP BY status"
    )}
    for s in STATUSES:
        counts.setdefault(s, 0)

    avg_row = db.execute("""
        SELECT AVG(
            (julianday(closed_at) - julianday(created_at)) * 24
        ) as avg_hours
        FROM tickets WHERE closed_at IS NOT NULL
    """).fetchone()
    avg_resolution = round(avg_row["avg_hours"] or 0, 1)

    top_agent = db.execute("""
        SELECT a.name, COUNT(t.id) as resolved
        FROM agents a
        JOIN tickets t ON t.agent_id = a.id
        WHERE t.status = 'closed'
        GROUP BY a.id
        ORDER BY resolved DESC
        LIMIT 1
    """).fetchone()

    priority_counts = {row["priority"]: row["total"] for row in db.execute(
        "SELECT priority, COUNT(*) as total FROM tickets GROUP BY priority"
    )}
    for p in PRIORITIES:
        priority_counts.setdefault(p, 0)

    recent = db.execute("""
        SELECT t.*, a.name as agent_name
        FROM tickets t LEFT JOIN agents a ON t.agent_id = a.id
        ORDER BY t.created_at DESC LIMIT 5
    """).fetchall()

    return render_template(
        "dashboard.html",
        counts=counts,
        avg_resolution=avg_resolution,
        top_agent=top_agent,
        priority_counts=priority_counts,
        recent=recent,
        statuses=STATUSES,
        priorities=PRIORITIES,
    )


# ---------------------------------------------------------------------------
# Routes — Tickets
# ---------------------------------------------------------------------------

@app.route("/tickets")
def ticket_list():
    db = get_db()
    status_filter = request.args.get("status", "")
    priority_filter = request.args.get("priority", "")
    search = request.args.get("q", "").strip()

    query = """
        SELECT t.*, a.name as agent_name
        FROM tickets t LEFT JOIN agents a ON t.agent_id = a.id
        WHERE 1=1
    """
    params = []
    if status_filter:
        query += " AND t.status = ?"
        params.append(status_filter)
    if priority_filter:
        query += " AND t.priority = ?"
        params.append(priority_filter)
    if search:
        query += " AND (t.title LIKE ? OR t.description LIKE ?)"
        params += [f"%{search}%", f"%{search}%"]

    query += " ORDER BY t.created_at DESC"
    tickets = db.execute(query, params).fetchall()
    agents = db.execute("SELECT * FROM agents ORDER BY name").fetchall()

    return render_template(
        "tickets.html",
        tickets=tickets,
        agents=agents,
        statuses=STATUSES,
        priorities=PRIORITIES,
        current_status=status_filter,
        current_priority=priority_filter,
        search=search,
    )


@app.route("/tickets/new", methods=["GET", "POST"])
def ticket_new():
    db = get_db()
    agents = db.execute("SELECT * FROM agents ORDER BY name").fetchall()

    if request.method == "POST":
        title = request.form["title"].strip()
        description = request.form["description"].strip()
        priority = request.form.get("priority", "medium")
        agent_id = request.form.get("agent_id") or None

        if not title or not description:
            flash("Title and description are required.", "danger")
            return render_template("ticket_form.html", agents=agents,
                                   statuses=STATUSES, priorities=PRIORITIES)

        now = datetime.now(timezone.utc).isoformat()
        db.execute(
            "INSERT INTO tickets (title, description, priority, agent_id, created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (title, description, priority, agent_id, now, now),
        )
        db.commit()
        flash("Ticket created successfully.", "success")
        return redirect(url_for("ticket_list"))

    return render_template("ticket_form.html", ticket=None, agents=agents,
                           statuses=STATUSES, priorities=PRIORITIES)


@app.route("/tickets/<int:ticket_id>")
def ticket_detail(ticket_id):
    db = get_db()
    ticket = db.execute("""
        SELECT t.*, a.name as agent_name
        FROM tickets t LEFT JOIN agents a ON t.agent_id = a.id
        WHERE t.id = ?
    """, (ticket_id,)).fetchone()

    if not ticket:
        flash("Ticket not found.", "danger")
        return redirect(url_for("ticket_list"))

    agents = db.execute("SELECT * FROM agents ORDER BY name").fetchall()
    return render_template("ticket_detail.html", ticket=ticket, agents=agents,
                           statuses=STATUSES, priorities=PRIORITIES)


@app.route("/tickets/<int:ticket_id>/edit", methods=["GET", "POST"])
def ticket_edit(ticket_id):
    db = get_db()
    ticket = db.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
    if not ticket:
        flash("Ticket not found.", "danger")
        return redirect(url_for("ticket_list"))

    agents = db.execute("SELECT * FROM agents ORDER BY name").fetchall()

    if request.method == "POST":
        title = request.form["title"].strip()
        description = request.form["description"].strip()
        priority = request.form.get("priority", ticket["priority"])
        status = request.form.get("status", ticket["status"])
        agent_id = request.form.get("agent_id") or None

        if not title or not description:
            flash("Title and description are required.", "danger")
            return render_template("ticket_form.html", ticket=ticket, agents=agents,
                                   statuses=STATUSES, priorities=PRIORITIES)

        now = datetime.now(timezone.utc).isoformat()
        closed_at = ticket["closed_at"]
        if status == "closed" and ticket["status"] != "closed":
            closed_at = now
        elif status != "closed":
            closed_at = None

        db.execute("""
            UPDATE tickets
            SET title=?, description=?, priority=?, status=?, agent_id=?,
                updated_at=?, closed_at=?
            WHERE id=?
        """, (title, description, priority, status, agent_id, now, closed_at, ticket_id))
        db.commit()
        flash("Ticket updated.", "success")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))

    return render_template("ticket_form.html", ticket=ticket, agents=agents,
                           statuses=STATUSES, priorities=PRIORITIES)


@app.route("/tickets/<int:ticket_id>/update-status", methods=["POST"])
def ticket_update_status(ticket_id):
    db = get_db()
    ticket = db.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
    if not ticket:
        flash("Ticket not found.", "danger")
        return redirect(url_for("ticket_list"))

    new_status = request.form.get("status")
    if new_status not in STATUSES:
        flash("Invalid status.", "danger")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))

    now = datetime.now(timezone.utc).isoformat()
    closed_at = now if new_status == "closed" else None
    db.execute(
        "UPDATE tickets SET status=?, updated_at=?, closed_at=? WHERE id=?",
        (new_status, now, closed_at, ticket_id),
    )
    db.commit()
    flash(f"Status updated to '{new_status}'.", "success")
    return redirect(url_for("ticket_detail", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/assign", methods=["POST"])
def ticket_assign(ticket_id):
    db = get_db()
    agent_id = request.form.get("agent_id") or None
    now = datetime.now(timezone.utc).isoformat()
    db.execute(
        "UPDATE tickets SET agent_id=?, updated_at=? WHERE id=?",
        (agent_id, now, ticket_id),
    )
    db.commit()
    flash("Ticket assigned.", "success")
    return redirect(url_for("ticket_detail", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/delete", methods=["POST"])
def ticket_delete(ticket_id):
    db = get_db()
    db.execute("DELETE FROM tickets WHERE id = ?", (ticket_id,))
    db.commit()
    flash("Ticket deleted.", "warning")
    return redirect(url_for("ticket_list"))


# ---------------------------------------------------------------------------
# Routes — Agents
# ---------------------------------------------------------------------------

@app.route("/agents")
def agent_list():
    db = get_db()
    agents = db.execute("""
        SELECT a.*, COUNT(t.id) as ticket_count
        FROM agents a
        LEFT JOIN tickets t ON t.agent_id = a.id
        GROUP BY a.id
        ORDER BY a.name
    """).fetchall()
    return render_template("agents.html", agents=agents)


@app.route("/agents/new", methods=["GET", "POST"])
def agent_new():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip()
        if not name or not email:
            flash("Name and email are required.", "danger")
            return render_template("agent_form.html", agent=None)
        now = datetime.now(timezone.utc).isoformat()
        try:
            get_db().execute(
                "INSERT INTO agents (name, email, created_at) VALUES (?, ?, ?)",
                (name, email, now),
            )
            get_db().commit()
            flash("Agent created.", "success")
            return redirect(url_for("agent_list"))
        except sqlite3.IntegrityError:
            flash("Name or email already exists.", "danger")

    return render_template("agent_form.html", agent=None)


@app.route("/agents/<int:agent_id>/delete", methods=["POST"])
def agent_delete(agent_id):
    db = get_db()
    db.execute("UPDATE tickets SET agent_id=NULL WHERE agent_id=?", (agent_id,))
    db.execute("DELETE FROM agents WHERE id=?", (agent_id,))
    db.commit()
    flash("Agent removed.", "warning")
    return redirect(url_for("agent_list"))


# ---------------------------------------------------------------------------
# Routes — Export
# ---------------------------------------------------------------------------

@app.route("/export")
def export():
    fmt = request.args.get("format", "csv")
    db = get_db()
    rows = db.execute("""
        SELECT t.id, t.title, t.description, t.status, t.priority,
               a.name as agent, t.created_at, t.updated_at, t.closed_at
        FROM tickets t LEFT JOIN agents a ON t.agent_id = a.id
        ORDER BY t.created_at DESC
    """).fetchall()

    df = pd.DataFrame([dict(r) for r in rows])
    if df.empty:
        df = pd.DataFrame(columns=["id","title","description","status","priority",
                                    "agent","created_at","updated_at","closed_at"])

    if fmt == "xlsx":
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Tickets")
        buf.seek(0)
        return send_file(
            buf,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=f"tickets_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
        )

    buf = io.StringIO()
    df.to_csv(buf, index=False)
    buf.seek(0)
    return send_file(
        io.BytesIO(buf.getvalue().encode()),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"tickets_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
    )


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    init_db()
    print("Support Ticket System running at http://127.0.0.1:5000")
    app.run(debug=True)
